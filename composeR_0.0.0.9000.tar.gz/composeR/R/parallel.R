
#' Apply functions in parallel.
#'
#' This function \href{https://en.wikipedia.org/wiki/Function_composition}{composes} two or more
#' functions to create a new function.
#'
#' If the first argument is the function \eqn{X(...)}, and the second argument is the function \eqn{Y(...)}, then the output
#' is the function \eqn{Z(...)}, such that \deqn{Z(...) = Y(X(...))}
#' In words, the new function applies the first function to an input, then applies the second function to the output
#' of the first function.
#' Thus, this | method acts like a UNix "pipe," passing the output of one function to the next.
#'
#' By default, the input to the new function is fed as the first argument to the first function
#' and the output of the first function is fed as the first argument to the second function, and so on.
#' The formal arguments of the new function will be the combination of all unique arguments to the composed functions.
#' If any of the composed functions have formals arguments with the same name, this argument will be fed to the function which is
#' earlier in the composition.
#' If any unnamed arguments are fed to the output function, they are fed to earlier functions first until they are used up.
#' If any functions have a \code{...} argument, all unnamed arguments will be fed to the first function which
#' takes a \code{...}.
#'
#' A simpler, more flexible way to specify arguments for individual functions,
#' is to partially apply any of the functions using \code{\link{Partialize}} or its shortcut infix ":" operator (\code{\link{:.function}}).
#'
#' @usage compose(func1, func2 (, func3 etc., funcnames))
#'
#' @param ... One or more input functions.
#' @param funcnames (Optional) A vector of
#' strings of the same length as the number of input functions.
#'
#' @return A new function which is a composition of the input functions.
#'
#' @seealso \code{\link{`:.function`}}
#'
#' @examples
#'
#' #####################################
#' ## An example with two functions:
#' #####################################
#'
#' # Create a new function which first takes the length of an input, then takes the square
#' # root of that length:
#' rootLength = compose(length, sqrt)
#'
#' # Apply this function to a vector of length 4:
#' rootLenth(c('A', 'B', 'C', 'D')) # and it returns 2.
#'
#' # This is the same as running:
#' sqrt(length(c('A', 'B', 'C', 'D')))
#'
#' # The same function can be created and applied inline, parentheses are used:
#' compose(length, sqrt)(c('A', 'B', 'C', 'D')) # Returns 2.
#'
#'
#'
#' ######################################
#' ## An example with three functions:
#' ######################################
#'
#' # An example with three functions:
#' LogLikelihood = compose(dnorm, log, sum)
#'
#' LogLikelihood(c(1, 2)) # Returns -4.33788.
#'
#' # This is the same as:
#' sum(log(dnorm(c(1, 2))))
#'
#'
#' ######################################
#' ## An example with additional arguments:
#' ######################################
#'
#' #If unamed arguments are fed to the output function,
#' they are first fed to the first function.
#' #
#' compose(dnorm, log)(2, 3, 5) #Returns -2.54838.
#' #The dnorm function takes up to four arguments.
#' #Since three unnamed arguments are fed to the new function, they are
#' used as the first three arguments to dnorm.
#' #Thus, this is equivalent to:
#' log(dnorm(x = 2, mean = 3, sd = 5))
#'
#' compose(dnorm, log)(2, 3, 5, FALSE, 3) #Returns -2.31963
#' #The first four unnamed arguments are fed to dnorm.
#' #The output of dnorm is fed as the first argument to log.
#' #Finally, the last unnamed argument is fed as the next argument to log.
#' #Thus, this example is the same as:
#' log(dnorm(x = 2, mean = 3, sd = 5, log = FALSE), base = 3)
#'
#' #The same thing can be achieved with partial application:
#' compose(dnorm : c(mean = 3, sd = 5, log = FALSE) | log : c(base = 3))(x = 2)
#'
#'
#' @rdname ParallelApplication
#'
#' @export
Parallel = (function(...) {

  # Input funcs
  funcs = list(...)
  if (any(!sapply(funcs, is.function)))  stop("Can't parallelize non-functions")

  # flatten previously composed functions
  funcs = unlist(sapply(funcs, fn := { if (inherits(fn, 'parallel')) components(fn) else fn}), 0)

  funcs = funcNames(funcs)
  # Create new func
  newfunc = function() {}

  # Formals
  funcsFormals = lapply(funcs, fargs)

  firstargs = sapply(funcsFormals, frms := { names(frms)[1] })
  if (unique(firstargs) %len!=% 1L) {
   newfirstarg = paste(unique(firstargs[firstargs != '...']), collapse = '_')
   funcsFormals = lapply(funcsFormals, function(frms) { c(setNames(alist(x=), newfirstarg), frms[-1]) } )
  }

  newfuncformals = unlist(rev(funcsFormals), recursive = FALSE, use.names = FALSE)

  names(newfuncformals) = unlist(lapply(rev(funcsFormals), names))
  newfuncformals = newfuncformals[!duplicated(names(newfuncformals))]
  newfuncformals = newfuncformals[c(which(names(newfuncformals) != '...'), which(names(newfuncformals) == '...'))] # put ... at end
  formals(newfunc) = newfuncformals

  # Body
  bodystr = 'list(' %str+% paste(collapse = ', ', Map( x:y:= {x %str+% ' \t\t= ' %str+% x %str+% "(" %str+% y %str+% ")"},
                 graveNamesIfNecessarry(names(funcs)),
                 lapply(funcsFormals, argString))) %str+% ')'

  body(newfunc) = parse(text = bodystr)

  # Environment
  environment(newfunc) = list2env(funcs)
  attr(newfunc, 'funcsFormals') = funcsFormals
  newfunc %class% 'parallel'

}) %class% 'composerRfunction'



#' @export
print.parallel = function(x) {

  funcs = components(x)
  cat('function [ ')
  formstrs = unlist(lapply(attr(x, 'funcsFormals'), argString, values = TRUE))


  cat(paste(gsub('\\(\\)', '', names(funcs) %str+% '(' %str+% formstrs %str+% ")"), collapse = ' & '))
  cat(' ]\n{\n\t')
  cat(gsub('))$', ')\n\t    )',
           gsub('), ', '),\n\t     ',
                gsub(' = ', '\t = ',
                     deparse(body(x))))))
  cat('\n}\n')
}





#############################################################################################################
#############################################################################################################
#############################################################################################################
#############################################################################################################


#' Infix based function composition
#'
#'
#' @export
ParallelInfix = (function(infix, ...) {
  # Input funcs
  funcs = list(...)
  if (any(!sapply(funcs, is.function)))  stop("Can't parallelize non-functions")

  # flatten previously composed functions
  componentfuncs = funcNames(unlist(lapply(funcs, fn := {if (composeR(fn)) components(fn) else fn}), 0))

  funcs = funcNames(funcs)
  # Create new func
  newfunc = function() {}

  # Formals
  funcsFormals = lapply(funcs, fargs)

  firstargs = sapply(funcsFormals, frms := { names(frms)[1] })
  if (unique(firstargs) %len!=% 1L) {
    newfirstarg = paste(unique(firstargs[firstargs != '...']), collapse = '_')
    funcsFormals = lapply(funcsFormals, function(frms) { c(setNames(alist(x=), newfirstarg), frms[-1]) } )
  }

  newfuncformals = unlist(rev(funcsFormals), recursive = FALSE, use.names = FALSE)

  names(newfuncformals) = unlist(lapply(rev(funcsFormals), names))
  newfuncformals = newfuncformals[!duplicated(names(newfuncformals))]
  newfuncformals = newfuncformals[c(which(names(newfuncformals) != '...'), which(names(newfuncformals) == '...'))] # put ... at end
  formals(newfunc) = newfuncformals

  # Body
  pre  <- if (composeR(funcs[[1]])) {
    '( ' %str+% deparse(body(funcs[[1]])) %str+% ' )'
    }  else {
      graveNamesIfNecessarry(names(funcs)[1]) %str+% '(' %str+% argString(funcsFormals[[1]]) %str+% ')'
      }

  post <- if (composeR(funcs[[2]])) {
    '( ' %str+% deparse(body(funcs[[2]])) %str+% ' )'
    } else {
      graveNamesIfNecessarry(names(funcs)[2]) %str+% '(' %str+% argString(funcsFormals[[2]]) %str+% ')'
      }

  bodystr <- pre %str+% infix %str+% post

  body(newfunc) = parse(text = bodystr)

  # Environment
  environment(newfunc) = list2env(componentfuncs)
  attr(newfunc, 'funcsFormals') = funcsFormals

  newfunc %class% c('parallelwithinfix', 'parallel')

}) %class% 'composerRfunction'

#' @export
print.parallelwithinfix = function(x) {
  funcs = components(x)
  cat('function [ ')
  formstrs = unlist(lapply(attr(x, 'funcsFormals'), argString, values = TRUE))


  cat(paste(gsub('\\(\\)', '', names(funcs) %str+% '(' %str+% formstrs %str+% ")"), collapse = ' & '))
  cat(' ]\n{\n\t')
  cat(deparse(body(x)))
  cat('\n}\n')
}

# #' @export -.function +.function *.function /.function ^.function
# #' @export <.function >.function <=.function >=.function ==.function !=.function
# #'
# for(fn in c('+', '-', '*', '/','^',
#             '<', '>', '<=', '>=', '==', '!=', '&&')) {
#
#   curfn = function() {}
#
#   formals(curfn) = as.pairlist(alist(e1 = , e2 = ))
#   body(curfn)    = parse(text = '{ ParallelInfix("' %str+% fn %str+% '", e1, e2) }')
#   assign(paste0(fn, '.function'), curfn)
#
# }
