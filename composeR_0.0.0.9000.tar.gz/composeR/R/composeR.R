 #' composeR: a package for assembling powerful functions.
 #'
 #' composeR is a suite of function operators, which can be used to
 #' create novel functions by combining existing functions in various ways.
"_PACKAGE"



