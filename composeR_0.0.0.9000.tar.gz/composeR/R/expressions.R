is.infixname = function(x) x %in% c(':', '::', '=', '==', '>=', '<=', '!=', '<', '>', '%%', '~', '|', '+', '||', '&', '&&', '^', '$', '@', '*', '/', '(', '[', '[[')

#' @export capture
capture = function(obj) {

  output = captureExpression(obj)
  if(is.na(output)) output = captureName(obj)
  if(is.na(output)) output = as.character(obj)

  attr(output, 'values') = append(list(), attr(output, 'values'))

  output %class% 'captured'

}

#' @export
flattencalltree = function(tree) {
  flat = as.list(tree)
  if(flat %len>% 1L) {unique(list(flat, lapply(flat, flattencalltree))) } else {flat[[1]]}
}


#' @export
funcNames = function(funcs) {
  if (any(!sapply(funcs, is.function))) stop("funcNames can't find names of non-functions.")

  calls = unique(unlist(lapply(head(sys.calls(), -1), flattencalltree)))
  nms   = Filter(function(call) !is.call(call) && as.character(call) != '' && is.name(call) && exists(as.character(call)) && is.function(eval(call)), calls)
  nms <- Filter(nm := !(deparse(nm) %in% c('func', 'funcs', 'fn')), nms)

  lapply(funcs,
         function(func) {
           unlist(Filter(function(nm)  identical(func, eval(nm)), nms))
         }) -> hits


  hits[sapply(hits, is.null)] = 'lambda' %str+% seq_len(sum(sapply(hits, is.null)))

  if(any(sapply(funcs, inherits, 'partialinfix'))) {
    hits[sapply(funcs, inherits, 'partialinfix')] = sapply(funcs[sapply(funcs, inherits, 'partialinfix')], attr, 'name')
  }

  hits = unlist(hits)

  composednames = lapply(funcs, attr, 'FuncNames')
  hits[sapply(composednames, Negate(is.null))] = composednames[sapply(composednames, Negate(is.null))]

  if (hits %len==% 0L) NA else setNames(funcs, hits)

}

#' @export captureName captureName.composed captureName.default
captureName = function(x) UseMethod('captureName')
captureName.composed = function(x) attr(x, 'name')
captureName.default =  function(xinputxxx_x) {
 calls = unlist(lapply(sys.calls(), flattencalltree))
 calls = lapply(calls, as.character)

 things = Filter(function(thing) {validNames(thing) && exists(thing)}, calls)
 things = things[things != 'xinputxxx_x']

 hits = unique(Filter(function(thing) {identical(get(thing), xinputxxx_x)} , things))

 if(hits %len==% 0L) return(NA) else output = hits[[1]]

 values = list()
 values[[output]] = xinputxxx_x
 attr(output, 'values') = values
 output %class% 'captured'
}

#' @export
captureExpression = function(xinputxxx_x) {
 things = unlist(lapply(sys.calls(), flattencalltree))

 values = unique(Filter(is.name, things))
 things = Filter(is.call, things)
 evaled = lapply(things,
                 function(thing) {
                   out = try(eval(thing), silent = TRUE)
                   if(out %len==% 1L && class(out) == 'try-error') NA else out
                 })
 hits = Position(function(thing) {identical(thing, xinputxxx_x)}, evaled)

 if(is.na(hits[1])) return(NA) else output = deparse(things[[hits]])

 names(values) = unlist(lapply(values, as.character))

 values = notInBase(values)

 values = lapply(values,
                 function(value) {
                   out = try(eval(value), silent = TRUE)
                   if((out %len==% 1L && class(out) == 'try-error') ||
                      (is.function(out) && identical(environment(out), .BaseNamespaceEnv))) NA else out
                 })
 values = Filter(Negate(is.null), values)

 values = values[!(names(values) %in% c('capture', 'freeze', 'freeze.function', 'freeze.character',
                                        'captureFormals', 'captureExpression', 'obj') | is.infixname(names(values)))]
 attr(output, 'values') = values
 output %class% 'captured'

}

notInBase = function(values) {
  values = lapply(values,
                  function(val) {
                    cur = find(as.character(val))
                    if(cur %len>% 0L && !any(gsub('package:', '', cur) %in%
                                          c('base', 'stats', '.GlovalEnv', 'utils', 'methods', 'graphics', 'stringr', 'plyr', 'grDevices', 'datasets')) ) {
                      return(cur)
                    }
                  })
  Filter(Negate(is.null), values)

}


#' @export
captureFormals = function(forms, ldots = NA, verbose = FALSE) {
#  forms = formals(args(sys.function(1L)))

  forms = forms[names(forms) != '...']
  args = forms

  for(arg in names(args)) {
    cur = try(dynGet(arg), silent = TRUE)
    if(class(cur)[1] == 'try-error') {
      args[[arg]] = ''
    } else {
      args[[arg]] = cur
    }
  }

  if(!verbose) args = args[!unlist(Map(identical, args, forms))]

  if(!any(is.na(ldots)))  args = c(args, ldots)

  args = lapply(args, capture)
  values = lapply(args, attr, 'values')
  values = Filter(function(x) x %len>% 0L, values)
  values = notInBase(values)

  args = lapply(args, function(x) ifelse(is.function(x), attr(x, 'name'), x))


  output = paste(collapse = ', ',
        gsub('^ = ', '',
             gsub(' = $', '',
                  paste0(names(args), ' = ', args))))

  attr(output, 'values') = values
  output
}
#' @export
print.captured = function(obj) {
  cat('  "', obj,'"\n', sep = '')

  if(attr(obj, 'values') %len>% 0L) {
    cat('          where\n')
    vars =  attr(obj, 'values')

   cat(sep = '',
        paste0('               ',
               graveNamesIfNecessarry(names(vars)),
               ' = ',
               lapply(vars, head, 10),
               ifelse(unlist(lapply(vars, length)) > 10, '...', ''),
               '\n'))
  }
}




#' @export freeze freeze.function freeze.character
freeze = function(obj) UseMethod('freeze')
freeze.function = function(func) {
  funcname = captureName(func)
  express = function() {}
  forms = formals(args(func))
  formals(express) = forms


  open = paste0(funcname, '(')
  close = ')'

  values = list()
  values[[funcname]] = func
  attr(express, 'values') = values

  body(express) = parse(text = paste(
    collapse = '\n',
    c('{',
      'formal = formals()',
      'ldots = any(names(formal) == "...")',
      'formal = formal[names(formal) != "..."]',
      'forms = list()',
      'for(i in names(formal)) { forms[[i]] = capture(get(i, inherits = FALSE))}',
      'if(ldots) forms = c(forms, as.list(match.call(expand.dots = FALSE)[["..."]]))',
      paste0('output = paste0("', open, '", paste(forms, collapse = ", "), "', close, '")'),
      'values = attr(forms, "values")',
      'attr(output, "values") = values',
      'output %class% "captured"',
      '}'))
  )

  envir = new.env()
  envir$forms = forms
  environment(forms) = envir

  express %class% 'frozen'
}
freeze.character = function(expr) {
  args = gsub('^\\$', '', str_extract_all(expr, '\\$.')[[1]])

  newfunc = function() {
    for(i in args) {
      expr = gsub(paste0('\\$', i), capture(get(i, inherits = FALSE)), expr)
    }
    expr
  }
  formals(newfunc) = setNames(alist(x = )[rep('x', length(args))], args)
  newfunc %class% 'frozen'
}
