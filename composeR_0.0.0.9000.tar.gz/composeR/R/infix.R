
#' @export
`%str+%`  <- function(e1, e2) paste0(e1, e2)


#' @export
`%str-%` <- function(e1, e2) {
  if (is.character(e2)) return(gsub(e2, '', e1))
  if (is.numeric(e2))  return(stringr::str_sub(e1, end = (-e2) - 1))
}

#' @export
`%strrid` <- `%str-%`

#' @export
`%strkeep%` <- function(e1, e2) {
  out <- stringr::str_extract(e1, e2)
  out[is.na(out)] <- ''
  out
}


#' @export
`%str*%` <- function(e1, e2){
  if (is.character(e2)) return(paste(e1, collapse = e2))

  match_size(e1 = e1, e2 = e2, toEnv = TRUE)

  if (is.numeric(e2)) {
    out <- Map(function(ch, n) collapse(rep(ch, n)),
               e1, e2)
    unlist(out)
  }
}


#' @export
`%str/%` <- function(e1, e2) {
  output <- strsplit(e1, split = e2)
  if (output %len==% 1L) output[[1]] else output
}

#' @export
`%str>%` <- function(e1, e2) {
  if (is.character(e2)) {
    pos <- stringr::str_locate(e1, e2)
    if (is.na(pos[1])) pos <- c(0, 0)
    to <- extend(pos[2])
  }  else {
    to <- extend(e2)
  }
  if (to >= 0) return(stringr::str_sub(e1, start = to +  1))
  if (to < 0)  return(stringr::str_sub(e1, end   = to - 1))
}
#' @export
`%str>=%` <- function(e1, e2) {
  if (is.character(e2)) {
    pos <- stringr::str_locate(e1, e2)
    if (is.na(pos[1])) pos <- c(0, 0)
    to <- extend(pos[2])
  }  else {
    to <- extend(e2)
  }
  if (to >= 0) return(stringr::str_sub(e1, start = to))
  if (to < 0)  return(stringr::str_sub(e1, end   = to))
}


#' @export
`%str<%` <- function(e1, e2) {
  if (is.character(e2)) {
    pos <- stringr::str_locate(e1, e2)
    if (is.na(pos[1])) pos <- c(0, 0)
    to <- extend(pos[2])
  }  else {
    to <- extend(e2)
  }
  if (to >= 0) return(stringr::str_sub(e1, 1, to - 1))
  if (to < 0)  return(stringr::str_sub(e1, to + 1))
}
#' @export
`%str<=%` <- function(e1, e2) {
  if (is.character(e2)) {
    pos <- stringr::str_locate(e1, e2)
    if (is.na(pos[1])) pos <- c(0, 0)
    to <- extend(pos[2])
  }  else {
    to <- extend(e2)
  }
  if (to >= 0) return(stringr::str_sub(e1, 1, to))
  if (to < 0)  return(stringr::str_sub(e1, to))
}


#' @export
`%str:%` <- function(e1, e2) {
  n1 <- char2num(e1)
  n2 <- char2num(e2)

  if (is.upper(e1)) LETTERS[n1:n2] else letters[n1:n2]
}




#' @export
`%ab%` = function(e1, e2) {
  modn <- if (is.character(e2)) char2num(e2) else e2

  lets <- if (is.upper(e1[1])) LETTERS else letters

  lets[char2num(e1) %mod% modn]
}

#' @export
`%|%` <- function(obj, func) func(obj)

#' @export
`%l|l%` <- function(obj, func) map(obj, func)
#' @export
`%l|ac%` <- function(obj, func) {
  out <- map(obj, func)
  do.call('cbind', out)
}
#' @export
`%l|ar%` <- function(obj, func) {
  out <- map(obj, func)
  do.call('rbind', out)
}
#' @export
`%l|dfc%` <- function(obj, func) map_dfc(obj, func)
#' @export
`%l|dfr%` <- function(obj, func) map_dfr(obj, func)



#' @export
`%l|v%` <- function(obj, func) unlist(map(obj, func))
#' @export
`%l|int%` <- function(obj, func) map_int(obj, func)
#' @export
`%l|dbl%` <- function(obj, func)  map_dbl(obj, func)
#' @export
`%l|lgl%` <- function(obj, func)  map_lgl(obj, func)
#' @export
`%l|chr%` <- function(obj, func)  map_chr(obj, func)
#' @export
`%l|%` <- function(obj, func) simplify2array(map(obj, func))

#########
hangingMath <- function(txt) {
  txt <- txt %str-% ' '
  txt <- txt %str/% '\n'
  txt <- gsub('^([+-])', '.\\1', txt)
  txt <- glue::collapse(txt, sep = '\n')
  txt
}
####
#' @export
map_names_inds <- function(obj, func, ..., .map = pmap) {
  forms <- fargs(func)
  ldots <- list(...)
  first <- names(forms)[!names(forms) %in% names(ldots)][1]

  inds <- seq_along(obj)

  if (anynames <- !is.null(names(obj))) {
    newforms <- alist(x = , y = )
    names(newforms) <- frst(names(forms)) %str+% c('name', 'ind')
  } else {
    newforms <- alist(y = )
    names(newforms) <- frst(names(forms)) %str+% 'ind'
  }

  forms <- c(forms, newforms)
  newfunc <- function() {}
  formals(newfunc) <- forms
  body(newfunc) <- body(func)
  environment(newfunc) <- environment(func)
  #
  if (anynames) {
    .map(list(obj, names(obj), seq_along(obj)), newfunc, ...)
  } else {
    .map(list(obj, seq_along(obj)), newfunc, ...)
  }

}

`.$expr` <- "if (is.list(.) &&  !is.null(names(.)) && !any(names(.) == '')) list2env(., environment())"

#' @export
`%lxl%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  map_names_inds(obj, .func)
}
#' @export
`%lx%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  simplify2array(map_names_inds(obj, .func))
}

#' @export
`%lxar%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  out <- map_names_inds(obj, .func)
  do.call('rbind', out)
}
#' @export
`%lxac%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  environment(.func) <- parent.frame()
  .func <- prependExpression(`.$expr`, .func)
  out <- map_names_inds(obj, .func)
  do.call('cbind', out)
}
#' @export
`%lxdfr%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  map_names_inds(obj, .func, .map = pmap_dfr)
}
#' @export
`%lxdfc%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  map_names_inds(obj, .func, .map = pmap_dfc)
}

#' @export
`%lxv%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  unlist(map_names_inds(obj, .func))
}
#' @export
`%lxint%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  unlist(map_names_inds(obj, .func, .map = pmap_int))
}
#' @export
`%lxdbl%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  unlist(map_names_inds(obj, .func,.map = pmap_dbl))
}
#' @export
`%lxlgl%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  unlist(map_names_inds(obj, .func, .map = pmap_lgl))
}
#' @export
`%lxchr%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()

  unlist(map_names_inds(obj, .func, .map = pmap_chr))
}





#' @export
`%|x%` <- function(obj, expr) {
  expr <- lazyeval::expr_text(expr)
  expr <- hangingMath(expr)

  .func <- function(.) {}
  body(.func) <- parse(text = expr)
  .func <- prependExpression(`.$expr`, .func)
  environment(.func) <- parent.frame()
  .func(obj)
}


#' @export
`%splat|%` <- function(obj, func) {
  if (is.atomic(obj)) obj <- as.list(obj)
  do.call(func, obj)
}

#' @export
`%split%` <- function(obj, factor) split(obj, factor)


#' Append to object's class.
#'
#' This simple infix appens a character string to the first position of
#' any object's class.
#' It returns the altered object, so it can simply be added to any assignment.
#' @export
#' @param object Any R object.
#' @param newclass The new class to be appended.
#' @rdname infix-ClassAssign
#'
#' @examples
#' x = rnorm(100) %class% 'NormallyDistributed'
#' class(x) # returns c('NormallyDistributed', 'numeric')
#'
`%class%` = function(object, newclass){
  class(object) = append(newclass, class(object))

  object
}

#############################
