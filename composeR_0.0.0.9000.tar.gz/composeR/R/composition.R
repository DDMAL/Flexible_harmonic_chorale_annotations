#' Function composition
#'
#' @rdname FunctionComposition
#' @export
compose = function(...) {
  funcs <- rev(list(...))


  forms <- fargs(funcs[[1]])

  bod <- call('Reduce',
              quote(function(f, arg) f(arg)),
              quote(funcs),
              init = quote(temp),
              right = quote(TRUE))
  bod[names(bod) == 'init'] <- list(init = as.name(names(forms)[1]))

  newfunc <- function() {  }
  body(newfunc) <- bod
  formals(newfunc) <- forms[1]

  newfunc
  }


#
# compose = (function(a, b, ...) {
#   aname <- lazyeval::expr_text(a)
#   bname <- lazyeval::expr_text(b)
#
#   afargs <- fargs(a)
#   bfargs <- fargs(b)[-1]
#
#   acall <- call(aname)
#   acall[[2]] <- as.name(names(afargs)[1])
#
#   bcall <- call(bname)
#
#   bcall[[2]] <- acall
#
#   newfunc <- function() {}
#   body(newfunc) <- bcall
#   formals(newfunc) <- afargs[1]
#
#   ldots <- list(...)
#   if (ldots %len>% 0) {
#
#
#   }
#
#   newfunc #%class% 'composed'
#
# }) %class% 'composerRfunction'
#
#



#' @export
components = function(composed) rev(as.list(environment(composed))) # as.list reverses order for some reason?


#' @export
print.composed = function(x) {

  funcs = components(x)
  cat('function [ ')

  forms = lapply(funcs, fargs)
  init(forms) = lapply(init(forms), '[', -1)
  formstrs = unlist(lapply(forms, argString, values = TRUE))

  cat(paste(gsub('\\(\\)', '', names(funcs) %str+% '(' %str+% formstrs %str+% ")"), collapse = ' . '))
  cat(' ]\n{\n\t')
  cat(deparse(body(x)))
  cat('\n}\n')

}

partialInfix = function(str) {
  newfunc = function(x) {}
  body(newfunc) = parse(text = ifelse(grepl('^[+-/*<>%^]', str), paste0('x', str), paste0(str, 'x')))
  attr(newfunc, 'name') = str
  newfunc %class% "partialinfix"
}

isPartialInfixable = function(str) {
  str = gsub('[\t ]*', '', str)
  grepl('^[+-/^<>*][0-9]*[.]?[0-9][0-9]*$', str) | grepl('^[0-9]*[.]?[0-9]+[+-/^<>*]', str)

}

#' @export
`%.%` <- function(e1, e2) { compose(e2, e1) }

