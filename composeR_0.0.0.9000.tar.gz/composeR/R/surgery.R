#' @export
stringSubstitutions = function(exprstring, substitutions) {
 for(i in seq_along(substitutions)){
  exprstring = gsub(names(substitutions)[i], substitutions[[i]], exprstring)
 }
 exprstring
}





#' String <-> Expression conversion
#'
#' @rdname stringexpr
#' @export
expr2string = function(expr){
 deparse(sys.calls()[[1]][[2]])
}


#' d
#'
#' @rdname stringexpr
#' @export
string2expr = function(str) {
 parse(text = str)
}

#' Prepend an expression to the body of a functon.
#'
#' This
#'
#' @export
prependExpression = function(expr, func) {
  if(is.primitive(func)) errorTree("Can't prepend expressions to the primitive function",
                                   deparse(substitute(func)),
                                   "because the bodies of primitive functions are hidden.")

  if(is.expression(expr))  exprstring = deparse(substitute(expr)) else exprstring = expr


  bod = deparse(body(func))

  if(bod[1] == '{') {
    body(func) = string2expr(paste(c(bod[1], exprstring, bod[2:length(bod)]), collapse = ' \n'))
  } else {
    body(func) = string2expr(paste(c('{ ', exprstring, bod, ' }'), collapse = ' \n '))
  }

  func

}



##############################################################



#' Create curried functions.
#'
#' A \code{\link[https://en.wikipedia.org/wiki/Currying]{curried function}} is a type of function
#' which only takes one argument. A curried function with multiple arguments is
#' actually a function which takes the first argument and returns a new function
#' which takes the second argument, and so on.
#'
#' @param args An alist, created by \code{\link[base]{alist}}, representing the names of the
#' function's formal arguments. They must be legal R names.
#'
#' @param expr An expression. An expression which forms the body of the function. Any expression
#' involving anything complex must be surrounded by \code{\{\}}.
#'
#'
#' @usage curriedfunction(c('x', 'y'), {x + y})
#'
#' @rdname Curry
#' @export
curriedfunction <- function(args, expr) {

  func <- function() {}
  formals(func) <- args

  isstring <- tryCatch(is.character(expr), error = function(e) FALSE)
  body(func) <- if (isstring) string2expr(expr) else substitute(expr)

  func <- prependExpression('if (any(misses)) {
                              formals(.self)[!misses] <- mget(names(.selfargs)[!misses])
                              formals(.self) <- formals(.self)[order(misses, decreasing = TRUE)]
                              environment(.self) <- environment()
                              if (sum(misses) == 1) {
                                  body(.self) <- parse(text = deparse(body(.self))[-2:-17])
                              } else {
                                  .self <- .self %class% "curried"
                              }
                              return(.self)}', func)
  # alternative approach -> formals(func) <- formals()[misses]
  func <- prependExpression('.self <- sys.function()
                            .selfargs <- formals(.self)
                            misses <- unlist(lapply(mget(names(.selfargs)), function(form) all(deparse(form) == "")))', func)
  func %class% 'curried'
}


#' @export
print.curried = function(x) {
  fullbody <- deparse(body(x))
  body(x) <- parse(text = fullbody[-2:-17])
  cat('curried ')
  invisible(print.function(x))

  ##variables in closure
  # vars <- ls(envir = environment(x))
  # vars <- vars[!vars %in% c('func', 'args', 'misses', 'expr', 'isstring', 'curried')]
  # if (length(vars) > 0) vars <- vars[!unlist(lapply(mget(vars, environment(x)), function(var) deparse(var) == ''))]
  # if(length(vars) > 0) {
  #   cat('          where\n')
  #
  #
  #   contents = unlist(lapply(vars,
  #                          function(v) {
  #                            obj = get(v, environment(x))
  #                            content = stringr::str_trim(capture.output(str(obj))[1], 'both')
  #                            content
  #                          }
  #   )
  #   )
  #   cat(sep = '',
  #       paste0('               ',
  #              graveNamesIfNecessarry(vars),
  #              ' = ', contents, '\n'))
  # }
}


#' Create curried functions.
#'
#' \code{curryfunction} takes a prexisting function and creates a curried version of that function.
#' As a curried function, the new function has no default arguments.
#'
#' \code{curryfunction} won't work on certain base functions: any function to which \code{body(function)}
#' returns \code{NULL}, or any function which calls methods.
#'
#'
#'
#' @param func A function, which will be curried.
#' @param argord Numeric or Logical vector of same length as the the number of formal
#' arguments that \code{func} accepts. Use this, to change the order of arguments in the new
#' function.
#'
#'
#' @rdname Curry
#' @export
curryfunction = function(func, argord = NA)  {
  funcbod <- body(func)

  if (is.null(funcbod)) stop("Can't curry this function, it's body is inaccessible.")
  if (any(grepl('\\.Call', deparse(funcbod))))  stop("Can't curry this function, it calls .Call().")

  funcargs <- fargs(func)


  curriedfunction(funcargs, funcbod)
}


#' \code{:=} can be used to make a curried function inline. To the left of the infix
#' the names of function's formals are specified, as naked expressions, separated by \code{:}.
#' To the right of the infix, an expression expressing the function's body.
#' If this expression is simple, and only used infixes of higher precedence than \code{:=},
#' you can get away without surrounding the expression with \code{\{\}}. However,
#' any more complex expression, or expression involving lower precedence infixes (like \code{&}), will
#' need to be surrounded by \code{\{\}}.
#'
#' @usage x := x^2
#' x|y := {x + y}
#'
#'
#'
#' @rdname Curry
#' @export
`%cf%` <- function(a, b) {
  a <- strsplit(deparse(substitute(a)), split =  ':')[[1]]

  forms <- alist(x = )[rep('x', length(a))]
  names(forms) <- a

  body <- deparse(substitute(b))

  curriedfunction(forms, body)

}

#' Make lambda function
#'
#' This is just a shorthand for \code{\link[base]{function}} (except it can't specify
#' default arguments).
#' To the left of the infix the names of function's formals are specified, as naked expressions, separated by \code{:}.
#' To the right of the infix, an expression expressing the function's body.
#' If this expression is simple, and only used infixes of higher precedence than \code{:=},
#' you can get away without surrounding the expression with \code{\{\}}. However,
#' any more complex expression, or expression involving lower precedence infixes (like \code{&}), will
#' need to be surrounded by \code{\{\}}.
#' @rdname Lambda
#'
#' @usage x:y:= x ^ y
#' @export
`:=` <- function(a, b) {
  a <- strsplit(deparse(substitute(a)), split =  ':')[[1]]

  forms <- alist(x = )[rep('x', length(a))]
  names(forms) <- a

  body <- deparse(substitute(b))

  func <- function() {}
  formals(func) <- forms
  body(func) <- string2expr(body)
  environment(func) <- parent.frame()
  func

}

#' Create inline function
#'
#' @rdname Lambda
#' @export
f. <- function(expr) {
  func <- function() {}
  formals(func) <- alist(. = )
  body(func) <- parse(text = lazyeval::expr_text(expr))
  environment(func) <- parent.frame()
  func
}







