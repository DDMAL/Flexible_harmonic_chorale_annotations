

createplyroperator = function(plyrname, ...) {
  plyrargnames = list(...)

  {function(func, ...) {

   plyrargs = list(...)

   newfunc = function() {}
   funcs = funcNames(list(func))

   forms = c(fargs(func), plyrargnames)
   formals(newfunc) = forms

   bodytext = '{' %str+% glue('{plyrname}(.data = {names(forms)[1]}, ')
   if (plyrargs %len>% 0L) bodytext <- bodytext %str+% argString(plyrargs, values = TRUE) %str+% ', '
   bodytext <- bodytext %str+% names(funcs)[1] %str+% ', ...) }'
   body(newfunc) = parse(text = bodytext)

   environment(newfunc) = list2env(funcs)

   newfunc %class% c('operated', glue('operation({plyrname})'))

  }} %class% c('operator', glue('operator({plyrname})'))

}


#' X -> X function operators
#'
#' These collection of function operators modify an input function so that it takes different input structures
#' and outputs different output structrues.
#' @rdname x2xoperation
#' @export .ll .la .ld .aa .al .ra .ca .ad .rd .cd
.ll  = createplyroperator('llply')
.la = createplyroperator('laply')
.ld = createplyroperator('ldply')
.al = createplyroperator('alply', '.margins')
.aa = createplyroperator('aaply', '.margins')
.ra = function(func) { function(data, ...) { aaply(data, 1, func, ...) }  }
.ca = function(func) { function(data, ...) { aaply(data, 2, func, ...) }  }
.ad = createplyroperator('adply', '.margins')
.rd = function(func) { function(data, ...) { adply(data, 1, func, ...) }  }
.cd = function(func) { function(data, ...) { adply(data, 2, func, ...) }  }

#' @export asC asI asD asF asL
asC = as.character
asI = as.integer
asD = as.double
asF = as.factor
asL = as.logical

#' @export asN asN.default asN.character
asN = function(x) UseMethod('asN')(x)
asN.character = function(x) {
  hits = nchar(x) == 1 & x %in% c(letters, LETTERS)
  x[hits] = match(tolower(x[hits]), letters)

  tryn = suppressWarnings(as.numeric(x))
  if(any(is.na(tryn) & !is.na(x))) as.numeric(x) else as.numeric(tryn)
}
asN.default = function(x) as.numeric


createtypeoperator = function(n1, n2 = NULL) {
  function(fn) {
    newfunc = function() { fff(...) }
    funcname = captureName(fn)
    formals(newfunc) = formals(args(fn))
    argstring = names(formals(newfunc))
    argstring[1] = paste0(n1, '(', argstring[1],')')
    argstring = paste(argstring, collapse = ', ')

    newbod = gsub('\\.\\.\\.', argstring, deparse(body(newfunc)))
    newbod = gsub('fff', funcname, newbod)
    if(!is.null(n2)) newbod = gsub(funcname %str+% '\\((.*)\\)', n2 %str+% '(' %str+% funcname %str+% '(\\1))', newbod)
    body(newfunc) = parse(text = newbod)
    newfunc
  }
}



#' @export .C_ .N_ .I_ .D_ .F_ .L_
.C_ = createtypeoperator('asC')
.N_ = createtypeoperator('asN')
.I_ = createtypeoperator('asI')
.D_ = createtypeoperator('asD')
.F_ = createtypeoperator('asF')
.L_ = createtypeoperator('asL')

#' @export .CC .CN .CI .CD .CF .CL
.CC = createtypeoperator('asC', 'asC')
.CN = createtypeoperator('asC', 'asN')
.CI = createtypeoperator('asC', 'asI')
.CD = createtypeoperator('asC', 'asD')
.CF = createtypeoperator('asC', 'asF')
.CL = createtypeoperator('asC', 'asL')

#' @export .NC .NN .NI .ND .NF .NL
.NC = createtypeoperator('asN', 'asC')
.NN = createtypeoperator('asN', 'asN')
.NI = createtypeoperator('asN', 'asI')
.ND = createtypeoperator('asN', 'asD')
.NF = createtypeoperator('asN', 'asF')
.NL = createtypeoperator('asN', 'asL')

#' @export .IC .IN .II .ID .IF .IL
.IC = createtypeoperator('asI', 'asC')
.IN = createtypeoperator('asI', 'asN')
.II = createtypeoperator('asI', 'asI')
.ID = createtypeoperator('asI', 'asD')
.IF = createtypeoperator('asI', 'asF')
.IL = createtypeoperator('asI', 'asL')

#' @export .DC .DN .DI .DD .DF .DL
.DC = createtypeoperator('asD', 'asC')
.DN = createtypeoperator('asD', 'asN')
.DI = createtypeoperator('asD', 'asI')
.DD = createtypeoperator('asD', 'asD')
.DF = createtypeoperator('asD', 'asF')
.DL = createtypeoperator('asD', 'asL')

#' @export .FC .FN .FI .FD .FF .FL
.FC = createtypeoperator('asF', 'asC')
.FN = createtypeoperator('asF', 'asN')
.FI = createtypeoperator('asF', 'asI')
.FD = createtypeoperator('asF', 'asD')
.FF = createtypeoperator('asF', 'asF')
.FL = createtypeoperator('asF', 'asL')

#' @export .LC .LN .LI .LD .LF .LL
.LC = createtypeoperator('asL', 'asC')
.LN = createtypeoperator('asL', 'asN')
.LI = createtypeoperator('asL', 'asI')
.LD = createtypeoperator('asL', 'asD')
.LF = createtypeoperator('asL', 'asF')
.LL = createtypeoperator('asL', 'asL')





#' Indexing function operators
#'
#' @rdname indop
#' @export .frst .scnd .last
.frst = function(fn) {
  forms = formals(args(fn))
  newfunc = function() {
    args = list(...)
    obj = args[[1]]
    args = args[-1]
    frst(obj) = do.call(fn, c(list(frst(obj)), args))
    obj
  }

  formals(newfunc) = forms
  argstring = paste(names(formals(newfunc)), collapse = ', ')
  body(newfunc) = parse(text =  gsub('\\.\\.\\.', argstring, deparse(body(newfunc))))

  newfunc
}

.scnd = function(fn) {
  forms = formals(args(fn))
  newfunc = function() {
    args = list(...)
    obj = args[[1]]
    args = args[-1]
    scnd(obj) = do.call(fn, c(list(scnd(obj)), args))
    obj
  }

  formals(newfunc) = forms
  argstring = paste(names(formals(newfunc)), collapse = ', ')
  body(newfunc) = parse(text =  gsub('\\.\\.\\.', argstring, deparse(body(newfunc))))

  newfunc
}

.last = function(fn) {
  forms = formals(args(fn))
  newfunc = function() {
    args = list(...)
    obj = args[[1]]
    args = args[-1]
    last(obj) = do.call(fn, c(list(last(obj)), args))
    obj
  }

  formals(newfunc) = forms
  argstring = paste(names(formals(newfunc)), collapse = ', ')
  body(newfunc) = parse(text =  gsub('\\.\\.\\.', argstring, deparse(body(newfunc))))

  newfunc
}


#' @export
`%skip%` <- function(.func, pred) {
  newfunc <- function(x) {
    hits <- !pred(x)
    result <- .func(x[hits])
    if (result %len==% as.integer(sum(hits))) {
      x[hits] <- result
      x
    } else {
      result
    }
  }
  attr(newfunc, 'FuncNames') <- glue('skip: ', lazyeval::expr_text(pred))
  newfunc
}

#' @export
`%applyto%` <- function(.func, pred) {
  newfunc <- function(x) {
    hits <- pred(x)

    result <- .func(x[hits])
    if (result %len==% as.integer(sum(hits))) {
      x[hits] <- result
      x
    } else {
      result
    }
  }
  attr(newfunc, 'FuncNames') <- glue('applyto: ', lazyeval::expr_text(pred))
  newfunc
}


#' @export
`%rid%` <- function(x, pred) {
  if (!is.function(pred)) pred <- EQ(pred)
  x[lapply(x, Negate(pred)) %|% unlist]
}

#' @export
rid <- curriedfunction(alist(pred = , x = ), { x %rid% pred })

#' @export
`%keep%` <- function(x, pred) {
  if (!is.function(pred)) pred <- EQ(pred)
  x[lapply(x, pred) %|% unlist]
}

#' @export
keep <- curriedfunction(alist(pred = , x = ), { x %keep% pred })

#' @export
strrid <- curriedfunction(alist(pattern = , str = ), { str %str-% pattern })

#' @export
strkeep <-  curriedfunction(alist(pattern = , str = ), {
  out <- stringr::str_extract(str, pattern)
  out[is.na(out)] <- ''
  out
  })

