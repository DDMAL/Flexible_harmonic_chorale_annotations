#' Check or compare length of objects
#'
#' These functions take two inputs. If the second input \code{\link[base]{is.integer}}
#' then it compares the length of the first object to to this integer (or vector of integers).
#' If the second argument \code{\link[base]{!is.integer}}, then the lengths of the two
#' arguments are compared.
#'
#' If either object has more than one dimension, the "length" is the number of rows.
#'
#' If you want to compare the lengths of two objects, and the second is a vector of integers,
#' you will need to coerce the integer vector to some other type, or else it won't work.
#' @param x A object with a length method (e.g. vectors), or a integer vector.
#' @param y A object with a length method (e.g. vectors), or a integer vector.
#' @rdname Lengthchecks
#' @export %len==% %len!=% %len>% %len<% %len>=% %len<=% len0 len1 lennot0
NULL
for (comparer in c('==', '!=', '>', '<', '>=', '<=')) {
  fun <- function(x, y) {}

  body(fun) <- parse(text = paste0('{;',
                                   'xl <- if (!hasdim(x)) { length(x) } else { nrow(x) };',
                                   'yl <- if (is.integer(y)) {y} else {if (is.null(dim(y))) {length(y) }else {nrow(y)}};',
                                    'xl', comparer, 'yl; }' ))
  assign(paste0('%len', comparer, '%'), fun)
}

#' @export lenEQ lennotEQ lenLT lenGT lenLoET lenGoET
lenEQ   <-  ( y:x  %cf% { x %len==% y  })
lennotEQ <- ( y:x  %cf% { x %len!=% y  })
lenLT   <-  ( y:x  %cf% { x %len<%  y  })
lenGT   <-  ( y:x  %cf% { x %len>%  y  })
lenLoET <-  ( y:x  %cf% { x %len<=% y  })
lenGoET <-  ( y:x  %cf% { x %len>=% y  })

len0 <- function(x) {if (!hasdim(x)) length(x) else nrow(x)} == 0L
len1 <- function(x) {if (!hasdim(x)) length(x) else nrow(x)} == 1L
lennot0 <- function(x) {if (!hasdim(x)) length(x) else nrow(x)} != 0L
#' Force the lengths of objects to match.
#'
#' Takes as many objects as you like (as separate argmuments) and recycles them to be the same size
#' along a given dimension. Dimensionsed objects (e.g. matrices, data.frames) are measured and recycled
#' along given dimension (\code{margin} argument). Dimensionless objects (e.g. vectors) are measured and
#' recycled by length, regardless what the \code{margin} arguments is set to.
#'
#' The recycled objects are output in a list.
#' If you want these objects to be named in the list, they should be
#' named as input arguments. If the parameter \code{toEnv} is \code{TRUE}
#' than the objects are actually assigned back into the calling environment with
#' their names (again, the names have to be given to the input arguments).
#'
#' The \code{size.ou}t argument controls the size of the outputted objects.
#' It can be a function which takes a set of numbers (representing) lengths
#' and returns a single number. By default, the argument is the function \code{\link[base]{max}}.
#' Thus, everything is recycled to the size of the largest input. If \code{\link[base]{min}} is
#' given instead, everything will match the length of the smallest object, etc.
#' Alternatively, \code{size.out} can just be a single number, and everything will be recycled to this size.
#' @export
match_size <- function(..., size.out = max, margin = 1, toEnv = FALSE) {
  stuff <- list(...)

  if (is.function(size.out)) {
    sizes <- sapply(stuff,
                    function(thing) {
                      dim <- dim(thing)
                      if (is.null(dim)) length(thing) else dim[margin]
                    })

    size.out <- size.out(sizes)
  }

  output <- lapply(stuff, Repeat, length.out = size.out, margin = margin)

  if (toEnv) list2env(output[names(output != '')], envir = parent.frame(1))

  if (toEnv) invisible(output) else output

}
