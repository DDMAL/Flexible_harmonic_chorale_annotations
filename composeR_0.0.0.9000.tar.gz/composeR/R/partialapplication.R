
  #' "Partial application" of a function.
  #'
  #' This function takes a function as well as some additional
  #' arguments (named or unnamed) and outputs a new function which is "partially applied" so
  #' that some of its arguments are fixed to the inputed additional arguments.
  #' Thus, the outputed function takes fewer arguments than the original function.
  #' This function is most useful in combination
  #' with the main \code{\link{composeR}} function composition operators \code{\link{`FunctionComposition`}}, xxx, and xxx.
  #'
  #' Imagine you have a function \eqn{F} which takes three arguments \eqn{X}, \eqn{Y},
  #' and \eqn{Z}:
  #' \deqn{F(X, Y, Z)}
  #' However, in your work you frequently use the same \eqn{X} input, let's say
  #' \eqn{X = 5}.
  #' We can create a new partially applied version of \eqn{F}, with \eqn{X} fixed to \eqn{5},
  #' using \code{PartialApplication}.
  #' Let's call this new function \eqn{Fx5}.
  #' \deqn{Fx5(Y,Z) = F(X = 5, Y, Z)}
  #' Now, we can use this new function, and never have to specify the \eqn{X} value.
  #'
  #' If an input function normally accepts
  #' four arguments and three of these arguments are fed to \code{PartialApplication}, the output function
  #' only accepts one argument.
  #' If the input function normally takes four arguments and \code{PartialApplication} is fed two additional arguments,
  #' then the new function will take two arguments.
  #'
  #' If no additional arguments are fed to \code{PartialApplication} (beyond the function), then the original
  #' function is returned unaltered.
  #' If the extra arguments are not named, they are assumed to follow the order
  #' of the input functions' arguments.
  #' Named arguments which are not among the named arguments of the input function,
  #' or excess arguments beyond the number the input function accepts, will result in errors.
  #' To keep code clear it is recommended that partial arguments be explicetely named.
  #'
  #' The original, unaltered function is retained as an attribute to the new function, in the attribute "componentfunctions."
  #'
  #' Atomic arguments are called directly in the body of the new function.
  #' If any arguments are expressions---e.g. seq(1, 10, 3) or 1:10---, the original expression
  #' is placed directly into the new function's body.
  #' This means that the expression is reevaulated every time the function is called, which
  #' in some cases may be slow.
  #'
  #' If a named variable is fed as an argument, as in: \cr
  #' : \code{x = 5} \cr
  #' : \code{PartialApplication(dnorm, mean = x)} \cr
  #' the variable is copied (with the same name) into the new function's enviroment.
  #' As a result, changing the variable after creating the partial function, will not change it's behavior.
  #' Thus, \cr\cr
  #' : \code{x = 5} \cr
  #' : \code{dnormx = PartialApplication(dnorm, mean = x)} \cr
  #' : \code{dnormx(5)} \cr\cr
  #' returns \code{.398942}, and \cr\cr
  #' : \code{x = 5} \cr
  #' : \code{dnormx = PartialApplication(dnorm, mean = x)} \cr
  #' : \code{x = 10} \cr
  #' : \code{dnormx(5)} \cr\cr
  #' also returns \code{.398942}.
  #' Changing the global variable does not affect the variable defined in the partially applied function!
  #'
  #' @param func Any function.
  #' @param ... Zero or mode additional arguments, named or not.
  #'
  #' @return A new function, a partially applied version of the original function.
  #' The new function's body should be fairly clear and easy to understand.
  #' The new function has the appropriate formal arguments, which can be seen using formals().
  #'
  #' @seealso \code{\link{Compose}}
  #'
  #' @examples
  #' # dnorm normally accepts four arguments, x, mean, sd, and log.
  #' # We can partially apply it, such that zero or more of these arguments are fixed to some value.
  #'
  #' dnormX5 = PartialApplication(dnorm, x = 1:2)
  #' dnormX5(4)
  #'   [1] 0.00443185 0.05399097
  #' #which is the same as dnorm(x = 1:2, 4)
  #'
  #' dnormM5 = PartialApplication(dnorm, mean = 5)
  #' dnormM5(4)
  #'   [1] 0.241971
  #' #which is the same as dnorm(4, mean = 5)
  #'
  #' dnormM5S4 = Partialize(dnorm, mean = 5, sd = 4)
  #' dnormM5S4(4)
  #'   [1] 0.096667
  #' #which is the same as dnorm(4, mean = 5, sd = 4)
  #'
  #' #The function can be used inline as well:
  #' Partialize(dnorm, mean = 5)(4)
  #'   [1] 0.241971
  #'
  #' @rdname PartialApplication
  #' @export
PartialApplication = function(func, ...) {

  # Input funcs and partial args
  stopifnot(is.function(func))

  partials <- list(...)
  if (partials %len==% 0L) return(func)
  if (is.null(names(partials))) names(partials) <- rep('', length(partials))

  c('named', 'unnamed') %<-% partition(names(partials) != '', partials)

  # Create new func
  forms <- fargs(func)
  ldots <- any(names(forms) == '...')
  if (ldots) {
    ldot <- forms[names(forms) == '...']
    forms <- forms[names(forms) != '...']
  }
  changed <- logical(length(forms))

  namedhits <- names(named) %in% names(forms)
  if (any(namedhits)) {
    forms[names(named)] <- named[namedhits]
    changed[names(forms) %in% names(named)] <- TRUE
    named <- named[!namedhits]
  }
  if (lennot0(unnamed)) {
     nunnamed <- min(sum(!changed), length(unnamed))
     targets <- which(!changed)[seq_len(nunnamed)]
     forms[targets] <- unnamed[seq_len(nunnamed)]
     unnamed <- unnamed[-seq_len(nunnamed)]

  }

  if (ldots) {
    forms <- c(forms, named)
    forms <- c(forms, ldot)
  }
  formals(func) = rev(forms)

  func
}

parseFormals <- function(forms, pas) {
  if (is.null(names(pas))) {
    named   = list()
    unnamed = pas
  } else {
    named   = pas[names(pas) != '']
    unnamed = pas[names(pas) == '']
  }

  newforms = forms
  newforms = newforms[!names(newforms) %in% names(named)] # remove named formals
  if (unnamed %len>% 0L) {
    names(unnamed) = names(newforms)[seq_along(unnamed)]
    newforms = newforms[!names(newforms) %in% names(unnamed)]
  }

  newpas = c(named, unnamed)
  if (!any(names(forms) == '...') && length(newpas) > length(forms)) newpas = newpas[seq_along(forms)]

  list(pas = newpas, formals = newforms)

}

#' @rdname PartialApplication
#' @export
pa <- PartialApplication

#' @export
print.partiallyapplied = function(x) {

  cat('function (')

  cat(argString(fargs(x), values = TRUE))
  cat(')')
#
  # cat(argString(attr(x, 'partials'), values = T))

  cat('\n{\n')
  cat('\t', deparse(body(x)))


  cat('\n}')
}
