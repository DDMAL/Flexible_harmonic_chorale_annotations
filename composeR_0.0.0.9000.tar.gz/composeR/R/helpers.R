#' Entropy, joint- or conditional- entropy of count data
#'
#' This function computes the entropy of a table of count data.
#' If \code{margin} is null, the joint entropy is computed. If a margin is given,
#'  the appropriate conditional entropy is computed.
#' @param tab. A table (or matrix) or count data.
#' @param base. The base of the logarithm.
#' @export
entropy <- function(tab, base = 2, margin = NULL) {

          joint <- prop.table(tab, margin = NULL)

          if (is.null(margin)) {
                    logs <- log(joint, base = base)
          } else {
                    cond <- prop.table(tab, margin = margin)
                    logs <- log(cond, base = base)
          }

          logs[logs == -Inf] <- 0

          ents <- joint * logs
          -sum(ents)
}

#' @export
collapsestr <- sep:str %cf% {
  paste(str, collapse = sep)
}


#' @export
allnamed <- function(x) { !is.null(names(x)) && !any(names(x) == '')}

#' @export
`%levels%` <- function(e1, e2) {
 factor(e1, levels = e2)
}

#' @export
IfElse <- function(true, yes, no) {
  out <- no
  if (any(true)) out[true] <- yes[true]
  out
}


#' @export
applyif <- pred : func : vec %cf% {
  if (is.function(pred)) {
    pred <- pred(vec)
  }

  targets <- vec[pred]
  new <- func(targets)

  if (length(new) == sum(pred)) {
    vec[pred] <- new
    vec
  } else {
    new

  }

}


#' Intercalate
#'
#' This intersperses one vector (this) in between each element of another vector (intothis).
#' @export
intercalate <- this : intothis %cf% {
  this <- lapply(this, rep, length(intothis) - 1)

  out <- c(list(intothis), this)

  inds <- lapply(out, seq_along)
  inds <- Map(`+`, inds, seq(0,.9, length.out = length(out)))
  unlist(out)[order(unlist(inds))]

}

#' @export
isSubset <- of:sets %cf% { sapply(sets, function(subset) all(subset %in% of)) }

#' Get unique values sorted.
#' @export
uset <- function(...) sort(unique(unlist(list(...))))

#' Pairwise addition, multiplication, and division, a la diff
#'
#' These functions act just like \code{\link[base]{diff}}, except doing addition,
#' multiplication and division.
#' @export prods divs prods sums
prods <- function(x, lag = 1, recurse = 0L) {
  stopifnot(recurse <= (length(x) - lag))

  out <- (x * rotate(x, lag))[-1:-lag]
  if (recurse > 0L) Recall(out, lag, recurse - 1) else out
}

divs <- function(x, numerator.first = TRUE, lag = 1, recurse = 0) {
  stopifnot(recurse <= (length(x) - lag))

  out <- if(numerator.first) (rotate(x, lag) / x)[-1:-lag] else (x / rotate(x, lag))[-1:-lag]


  if (recurse > 0L) Recall(out, numerator.first, lag, recurse - 1) else out
}

sums <- function(x, lag = 1, recurse = 0) {
  stopifnot(recurse <= (length(x) - lag))

  out <- (x + rotate(x, lag))[-1:-lag]
  if (recurse > 0L) Recall(out, lag, recurse - 1) else out
}

#' Repeat in multiple dimensions.
#'
#' This is a wrapper for \code{\link[base]{rep}} which
#' can repeat multidimensional matrices.
#' @export
Repeat <- function(x, ..., margin = 2) {
  if (is.null(dim(x))) {
    out <- do.call('rep', list(x = x, ...))
  } else {
    out <- do.call('apply', list(X = x, MARGIN = margin, FUN = rep, ...))
    if (margin == 1) out <- t(out)

    if (is.data.frame(x)) out <-  as.data.frame(out, stringsAsFactors = FALSE)

    if (!is.null(rownames(out)))  rownames(out) <- make.unique(rownames(out))
    if (!is.null(colnames(out)))  colnames(out) <- make.unique(colnames(out))
  }
  out
}


#' Access formals arguments
#'
#' This is a wrapper of \code{\link[base]{formals}}, which works on any function,
#' unlike \code{\link[base]{formals}}, which doesn't work on certain base functions.
#' @export
fargs = function(func = sys.function(1L)) formals(args(func))


#' @export
`%mod1%` <- function(e1, e2) ((e1 - 1) %% e2) + 1

#' @export mod mod1
mod  <- m:n %cf% {n %% m}
mod1 <- m:n %cf% {n %mod1% m}



#' Check if names are valid
#'
#' This function takes a list of prospective object names as a vector of character strings
#' and checks if the names are syntactically valid.
#'
#' @export
validNames = function(names) { names == make.names(names, unique = FALSE) }

#' @export
grave = function(x) paste0('`', gsub('`', '', x), '`')

#' Add grave (``backticks'') the names that are not syntactically valid.
#' @export
graveNamesIfNecessarry = function(names) {
 names[!validNames(names)] = grave(names[!validNames(names)])
 names
}


#' Special error
#' @export
errorTree = function(...) {
  message = do.call('paste0', list(...))

 calltree = head(sys.calls(), -1)
 stop(call. = FALSE,
        paste0('\n\tAn error occured in the call(s):\n\t\t',
             paste(collapse = ' > ', unlist(lapply(calltree, function(x) paste(deparse(x), collapse = ' ')))),
            '\n\n\tThe problem is in the call "',
            tail(calltree, 1),

            '", which says:\n\n\t\t', message))
}




#' @export
popclass <- function(object) `class<-`(object, class(object)[-1])

#' @export
makePairlist = function(formalnames, defaults = NULL) {
  alist = setNames(alist(x = )[rep('x', length(formalnames))], formalnames)

  if(!is.null(defaults)) {  alist[names(defaults)] = defaults }

  as.pairlist(alist)

}


#' Translate whole numbers in the range [0, 100] to English words.
#' @export
num2word = function(num) {
  words = c('zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine',
            'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen')
  tens = c('', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety')


  out = num
  out[num < 101] = unlist(lapply(num[num < 101],
                                 function(n) {
                                   if(n == 100) return('one-hundred')
                                   if(n < 20) { words[n + 1]  } else {
                                    gsub('-zero$', '', paste0(tens[1 + floor(n / 10)], '-', words[n %% 10 + 1]))
                                   }
                                   }
                                 )
                          )
  out
}



####Multireturn

#' Assign (list) output of function to multiple names.
#'
#' This function is a conveniant wrapper to list2env, which allows
#' you to mimic multiple return in R.
#' It takes a list and assigns each element in that list to names provided by the user.
#' Thus, if an R function returns a list, each element of that list can be assigned to a name, all at once.
#'
#'
#' The names must be provided as a vector, either of character strings, or naked names.
#' Character strings will be safer if you use the %->% operator inside other functions, but
#' using naked names should work fine in most cases.
#'
#'
#' @usage list %->% c(Name1, Name2[, Name3, etc.])
#'
#' @param list A list.
#' @param names A vector of names, either as character strings or naked names.
#'
#' @export %->% %<-%
`%->%` <- function(l, nms = NULL) {
  #' @title Assign list of values to multiple names
  #'
  #' These functions allow one to assign each element
  #' @rdname multiassign
  #' @export
  if (!is.null(nms)) names(l)[nms != ''] <- nms[nms != '']

  if (length(names(l)) > 0) l <- l[names(l) != '' & !is.na(names(l))]
  if (length(names(l)) == 0) return(invisible(NULL))

  list2env(l, envir = parent.frame(1))
  invisible(names(l))
}

`%<-%` <- function(nms = NULL, l) {
  #' @title Assign list of values to multiple names
  #' @rdname multiassign
  if (!is.null(nms)) names(l)[nms != ''] <- nms[nms != '']
  #' @export

  if (length(names(l)) > 0) l <- l[names(l) != '' & !is.na(names(l))]
  if (length(names(l)) == 0) return(invisible(NULL))

  list2env(l, envir = parent.frame(1))
  invisible(names(l))
}


###rounding

extend = function(x) {
  #' Round numbers in relation to zero.
  #'
  #' These functions expand on the concept of the \code{\link{trunc}} function:
  #' The \code{trunc} function allows one to round a number towards zero, meaning that negative
  #' numbers are rounded upwards while positive numbers are rounded downward.
  #' Another way of thinking of it is that the \emph{absolute value(s)} of the input number(s) are floored,
  #' while retaining the original sign.
  #' The \code{extend} function is to \code{\link{ceiling}} as \code{\link{trunc}} is to \code{\link{floor}}.
  #' It allows one to round a value away from zero, meaning that negative numbers are rounded downward,
  #' while positive numbers are rounded upward. Thus, the absolute value of the input numbers are ceilinged,
  #' while retaining their sign.
  #'
  #' @rdname roundabs
  #'
  #' @export
  #' @examples
  #'
  #' extend(c(-2.5, 2.5))
  #' # returns c(-3, 3)
  #'
  #' floorabs(c(-2.5, 2.5))
  #' # returns c(-2, 2)

  ceiling(abs(x)) * sign(x)
}


#' @export
roundTo    <- to:n %cf% { round(n / to)   * to }
#' @export
floorTo    <- to:n %cf% { floor(n / to)   * to }
#' @export
ceilingTo  <- to:n %cf% { ceiling(n / to) * to }
#' @export
truncTo    <- to:n %cf% { trunc(n / to)   * to }
#' @export
extendTo   <- to:n %cf% { extend(n / to)  * to }

###
#' Grep for multiple patterns
#' @export
grepls = function(patterns, string, combine = any) {
  if (len1(patterns)) return(grepl(patterns, string))

  matches <- matrix(sapply(patterns, grepl, x = string), ncol = length(patterns))
  apply(matches, 1, combine)

}


#' @export
greplmat = function(pattern, obj) {
  outmat = apply(obj, 2, grepl, pattern = pattern)
  colnames(outmat) = colnames(obj)
  rownames(outmat) = rownames(obj)

  if (is.data.frame(obj)) {obj[] <- outmat ; return(obj) }

  outmat

}

#' @export
setClass('predicate.function', contains = 'function', slots = c(string = 'character'))

#' @export
setMethod('show', signature = c(object = 'predicate.function'),
          function(object) {
            cat('function (x)\n\t')
            cat(object@string)
            cat('\n')
          })

#' @export
setMethod('|', signature = c(e1 = 'predicate.function', e2 = 'predicate.function'),
          function(e1, e2) {
            func <- function(x) e1(x) | e2(x)

            str1 <- e1@string
            str2 <- e2@string

            if (grepl('[|&]', str1)) str1 <- glue::glue('( {str1} )')
            if (grepl('[|&]', str2)) str2 <- glue::glue('( {str2} )')

            newstring <- glue::glue('{str1} | {str2}')

            new('predicate.function', func, string = newstring)
          })



#' @export
setMethod('&', signature = c(e1 = 'predicate.function', e2 = 'predicate.function'),
          function(e1, e2) {
            func <- function(x) e1(x) & e2(x)

            str1 <- e1@string
            str2 <- e2@string

            if (grepl('[|&]', str1)) str1 <- glue::glue('( {str1} )')
            if (grepl('[|&]', str2)) str2 <- glue::glue('( {str2} )')

            newstring <- glue::glue('{str1} & {str2}')

            new('predicate.function', func, string = newstring)
          })


#' @export
RE <- function(pat) {
  func <- function(x)  if (!hasdim(x)) grepl(pat, x) else greplmat(pat, x)
  attr(func, 'FuncNames') <- glue('~{deparse(pat)}')
  new('predicate.function', func, string = glue::glue('x ~ {deparse(pat)}'))
}
#' @export
notRE <- function(pat) {
  func <- function(x)  if (!hasdim(x)) !grepl(pat, x) else !greplmat(pat, x)
  attr(func, 'FuncNames') <- glue('!~{deparse(pat)}')
  new('predicate.function', func, string = glue::glue('x !~ {deparse(pat)}'))
}

# EQ <- ( pat | x  %cf% {
#   match_size(pat = pat, x = x, toEnv = TRUE)
#   ifelse(is.na(pat), is.na(x), x == pat)
#   })
#' @export
EQ <- function(pat) {
  func <- function(x) {
    c('pat', 'x') %<-% match_size(pat,x)
    ifelse(is.na(pat), is.na(x), x == pat)
  }

  attr(func, 'FuncNames') <- glue('=={deparse(pat)}')

  new('predicate.function', func, string = glue::glue('x == {deparse(pat)}'))
}
#' @export
notEQ <- function(pat) {
  func <- function(x) {
    c('pat', 'x') %<-% match_size(pat,x)
    ifelse(is.na(pat), !is.na(x), x != pat)
  }
  attr(func, 'FuncNames') <- glue('!={deparse(pat)}')
  new('predicate.function', func, string = glue::glue('x != {deparse(pat)}'))
}

#' @export
GT <- function(n) {
  func <- function(x) x > n
  attr(func, 'FuncNames') <- glue('>{deparse(n)}')
  new('predicate.function', func, string = glue::glue('x > {deparse(n)}'))
}
#' @export
GoET <- function(n) {
  func <- function(x) x >= n
  attr(func, 'FuncNames') <- glue('>={deparse(n)}')
  new('predicate.function', func, string = glue::glue('x >= {deparse(n)}'))
}
#' @export
LT <- function(n) {
  func <- function(x) x < n
  attr(func, 'FuncNames') <- glue('<{deparse(n)}')
  new('predicate.function', func, string = glue::glue('x < {deparse(n)}'))
}
#' @export
LoET <- function(n) {
  func <- function(x) x > n
  attr(func, 'FuncNames') <- glue('<={deparse(n)}')
  new('predicate.function', func, string = glue::glue('x <= {deparse(n)}'))
}





#' @export %~% %!~% %~i% %~x% %sub%
`%~%`   <- function(obj, regex) grepl(regex, obj)
`%!~%`   <- function(obj, regex) !grepl(regex, obj)
`%~i%`  <- function(obj, regex) grep(regex, obj)
`%~x%`  <- function(obj, regex) grep(regex, obj, value = TRUE)
`%sub%` <- function(regex, replace) function(obj) gsub(regex, replace, obj)

#' @export %all==% %all!=% %any==% %any!=%
`%all==%` <- function(obj, test) lapply(obj, function(el) all(el == test))
`%all!=%` <- function(obj, test) lapply(obj, function(el) all(el != test))
`%any==%` <- function(obj, test) lapply(obj, function(el) any(el == test))
`%any!=%` <- function(obj, test) lapply(obj, function(el) any(el != test))


#' @export rotate rotate.matrix rotate.data.frame rotate.default
rotate <- function(obj, rotation = 1, wrap = FALSE, pad = NA, ...) UseMethod('rotate')

rotate.matrix <- function(mat, rotation = 1, margin = 1, wrap = FALSE, pad = NA) {
          if ( margin %len>% 1L ) {
                    rest.mar <- margin[-1]
                    margin   <- margin[1]

                    rest.rot <- if (rotation %len>% 1L ) rotation[-1] else rotation

                    on.exit(return(Recall(output, rotation = rest.rot, margin = rest.mar, wrap = wrap))        )
          }
          rotation <- rotation[1]

          size <- dim(mat)[margin]
          rotation = sign(rotation) * (abs(rotation) %% size) #if rotation is greater than size, or negative, modulo
          if (rotation == 0) return(mat)

          ind <- seq_len(size) - rotation

          if (wrap) ind <- ind %mod% size else ind[ind > size | ind < 1] <- NA

          calls <- alist(mat, i = , j = )
          calls[[margin + 1]] <- ind

          output <- do.call('[', calls)

          if (!is.na(pad)) {
                    calls[[margin + 1]] <- which(is.na(ind))
                    calls$value <- pad
                    calls[[1]] <- output
                    output <- do.call('[<-', calls)

          }

          output

}

rotate.data.frame <- function(df, rotation = 1, margin = 1, wrap = FALSE, pad = NA) {
         df[] <- rotate.matrix(as.matrix(df), rotation = rotation, margin = margin, wrap = wrap, pad = pad)
         Map(rotation, margin,
             f = function(r, m) {
                              newnames <- rotate(dimnames(df)[[m]], r, wrap = wrap, pad = '')
                              dimnames(df)[[m]] <<- make.names(newnames, TRUE)
                       }
             )
         df
}

rotate.default <- function(obj, rotation = 1, wrap = FALSE, pad = NA) {
          rotation <- rotation[1]

          size <- length(obj)
          rotation = sign(rotation) * (abs(rotation) %% size) #if rotation is greater than size, or negative, modulo
          if (rotation == 0) return(obj)

          ind <- seq_len(size) - rotation

          if (wrap) ind <- ind %mod% size else ind[ind > size | ind < 1] <- NA

          output <- obj[ind]

          if (!is.na(pad)) output[which(is.na(ind))] <- pad

          output
}

strsplit_single = function(string, pattern) {unlist(strsplit(string, pattern))}
#########
#tools use in hum_score

#' @export
is.upper = function(ch) ch == toupper(ch)
#' @export
is.lower = function(ch) ch == tolower(ch)





######################################################
##############################Faux-algabreic pass functions
########################################################


#' Identity function
#' @export
id <- force

#' @export
hasdim <- function(x) !is.null(dim(x))

#' \emph{composeR} vector indexing functions
#'
#' @rdname Indexing
#' @export frst frst<- scnd scnd<- last last<- frst<- scnd<- last<- init init<- rest tAIL<- tail<- head<-
frst <- function(x) {
  if (len0(x)) return(vector(mode(x)))

  if (!hasdim(x)) x[[1]] else x[1, , drop = FALSE]
}
scnd <- function(x) {
  if (x %len<% 2L) return(vector(mode(x)))

  if (!hasdim(x)) x[[2]] else x[2, , drop = FALSE]
}
last <- function(x) {
  if (len0(x)) return(vector(mode(x)))

  if (!hasdim(x)) x[[length(x)]] else x[nrow(x), , drop = FALSE]
}
init <- function(x, n = 1) {
  if (len0(x)) return(vector(mode(x)))

  if (!hasdim(x)) x[1 : (length(x) - n)] else x[1 : (nrow(x) - n), , drop = FALSE]
}

rest <- function(x, n = 1) {
  if (x %len<% 2L) return(vector(mode(x)))

  if (!hasdim(x)) x[(n + 1) : length(x)] else x[(n + 1) : nrow(x), , drop = FALSE]
}

#' @export Head Tail
Head <- n:x %cf% head(x, n = n)
Tail <- n:x %cf% tail(x, n = n)

`frst<-` = function(x, value) {
  if (!hasdim(x) || length(dim(x)) == 1) x[[1]] <- value else x[1, ] <- value
  x
 }
`head<-` = function(x, n = 6, value) {
  if (!hasdim(x) || length(dim(x)) == 1) x[1 : n] <- value else x[1 : n, ] <- value
  x
}
`scnd<-` = function(x, value) {
  if (!hasdim(x) || length(dim(x)) == 1) x[[2]] <- value else x[2, ] <- value
  x
}
`last<-` = function(x, value) {
  if (!hasdim(x) || length(dim(x)) == 1) x[[length(x)]] <- value else x[nrow(x), ] <- value
  x
}
`init<-` = function(x, n = 1, value) {
  if (!hasdim(x) || length(dim(x)) == 1) x[1 : (length(x) - n)] <- value else x[1 : (nrow(x) - n), ] <- value
  x
}
`tAIL<-` = function(x, n = 1, value)    {
  if (!hasdim(x) || length(dim(x)) == 1) x[(n + 1) : length(x)] <- value else x[(n + 1) : nrow(x), ] <- value
  x
}
`tail<-` = function(x, n = 6, value)    {
  if (!hasdim(x) || length(dim(x)) == 1) x[(length(x) - n) : length(x)] <- value else x[(nrow(x) - n) : nrow(x), ] <- value
  x
}

#' Indexing infixes.
#'
#' These functions are used to index elements of a list.
#'
#' @export %i% %I% %j% %ij%
`%i%` <- function(obj, i) llply(obj, '[', i = i)
`%I%` <- function(obj, i) llply(obj, '[[', i = i)
`%j%` <- function(obj, j) llply(obj, '[', j = j)
`%ij%` <- function(obj, ij) llply(obj, '[', i = ij[[1]], j = ij[[2]])


#' Indexing functions.
#'
#' These are a set of curried functions, mainly for use in a pipe.
#' @export i ii j ij
i  <- I:x    %cf% x[I]
ii  <- I:x    %cf% x[[I]]
j  <- J:x    %cf% x[ , J]
ij <- I:J:x  %cf% x[I, J]


#' composeR string formatting
#'
#' These functions are useful wrappers for various
#' string printing uses.
#'
#' @rdname stringformatting
#' @export
spaceCamelCase <- function(strs) gsub('([a-z])([A-Z])', '\\1 \\2', strs)


#' @rdname stringformatting
#' @export
num2str <- function(n, pad = FALSE) format(n, digits = 3, trim = !pad, zero.print = T, big.mark = ',', justify = 'right')

#' @rdname stringformatting
#' @export
char2num <- function(char) match(tolower(char), letters)

#' @rdname stringformatting
#' @export
padder <- function(strs, sizes = max(nchar(strs)) + 1) {unlist(Map(stri_pad_left, strs, sizes))}

#' @rdname stringformatting
#' @export
trimLongString <- function(strs, n = 20L) {
  strs[str_length(strs) > n] <- paste0(stri_trim_both(str_sub(strs[str_length(strs) > n], end = n)), '...')
  strs
}

###########Miscalaneus




#' @export between between_in %><% %=><=%
between    <- bottom:top:n %cf% { n >  bottom & n <  top }
between_in <- bottom:top:n %cf% { n >= bottom & n <= top }

`%><%`   <- function(bottom, top) function(n) between(bottom, top)
`%=><=%` <- function(bottom, top) function(n) between_in(bottom, top)


#' Integer tests
#'
#'
#' @rdname IntegerTests
#' @export is.whole is.odd is.even
is.whole <- function(n) n == round(n)
is.odd   <- function(n) n %% 2 == 1
is.even  <- function(n) n %% 2 == 0

#' @export
read.tsv <- function(file, header = FALSE, ...) {
  read.delim(file, header = header, stringsAsFactors = FALSE, sep = '\t',...)
}
#' @export
read.tsvs <- function(pattern, path = getwd(), ...) {
  filenames <- dir(path, pattern, full.names = TRUE)

  files <- lapply(filenames, read.tsv, ...)

  names(files) = filenames

  files
}


#' @export Plot Axis Xax Yax Barplot Barplots Plotlayout
NULL

Plotlayout <- function(obj, ncol = NULL, nrow = NULL) {
 n <- length(obj)

 if (is.null(ncol) && is.null(nrow)) ncol <- 1
 if (is.null(ncol) && !is.null(nrow)) ncol <- ceiling(n / nrow)
 if (!is.null(ncol) && is.null(nrow)) nrow <- ceiling(n / ncol)

 nplots <- ceiling(n / (nrow * ncol))

 list(mf = c(nrow, ncol), Nplots = nplots)

}

Plot = function(x = NA, y = NA, ...) {

  args <- list(...)

  if (all(is.na(x)) & all(is.na(y))) {
    args$type = 'n'
    x = 0
    y = 0
  } else {
    if (all(is.na(x))) {
      x = if (all(is.na(y))) 0 else numeric(length(y))
    }
    if (all(is.na(y))) {
      y = if (all(is.na(x))) 0 else seq_along(x)
    }
  }
  args <- append(list(x = x, y = y), args)
  args$axes = FALSE

  if (!any(names(args) == 'xlab')) args$xlab = ''
  if (!any(names(args) == 'ylab')) args$ylab = ''
  if (!any(names(args) == 'pch')) args$pch = 16
  if (!any(names(args) == 'cex')) args$cex = .7

  do.call('plot', args)
}


Barplot <- function(height, ...) {
          args <- list(...)

          args <- append(list(height = height), args)
          print(args)
          args$axes <- FALSE
          args$border <- NA

          if (!any(names(args) == 'xlab')) args$xlab <- ''
          if (!any(names(args) == 'beside')) args$beside <- TRUE
          if (!any(names(args) == 'space')) args$space <- c(0, .5, 1, 1)[seq_len(length(dim(height)))]
          if (!any(names(args) == 'ylab')) args$ylab <- ''

          do.call('barplot', args)
}

Barplots <- function(heights, ncol = NULL, nrow = NULL, byRow = TRUE, file = NULL, ...) {
  layout <- Plotlayout(heights, ncol, nrow)
  groups <- rep(seq_len(layout$Nplot),
                each = prod(layout$mf),
                length.out = length(heights))

  if (!is.null(file)) {
    extension <- stringr::str_match(file,'\\.[^.]{3}$')
    file <- stringr::str_replace(file,'\\.[^.]{3}$','')
    if (is.na(extension)) extension = '.pdf'
    file <- rep(file, layout$Nplots)
    file <- paste0(make.unique(file, sep = '_'), extension)
    printfun <- match.fun(extension %str>% 1)
  }
  ##
  for(i in unique(groups)) {
    hs <- heights[groups == i]

    if (!is.null(file)) {
      printfun(file[i])
    } else {
      X11()
    }

    oldpar <- if (byRow) par(mfrow = layout$mf) else par(mfcol = layout$mf)

    invisible(lapply(hs, Barplot, ...))

    par(oldpar)

    if (!is.null(file)) dev.off()

  }
}


Xax <- function(at = NULL, labels = at, ...) axis(1, at, labels, las = 1, tick = FALSE, ...)
Axis <- function(side = 1, at = NULL, labels = at, ...) axis(side, at, labels, las = 1, tick = FALSE, ...)
Yax <- function(at = NULL, labels = at, ...) axis(2, at, labels, las = 1, tick = FALSE, ...)

slur <- function(x0, x1, y0, y1, n = 36, rat = .1, ...) {
  X <- seq(x0, x1, length.out = n)
  Y <- seq(y0, y1, length.out = n)

  len <- dist(rbind(c(x0, y0), c(x1, y1)))

  sins <- sin(seq(0, pi, length.out = n)) * len * rat

  if (y1 < y0) sins <- sins * -1

  Y <- Y + sins + rev(sins)
  X <- X - sins

  endcut <- round(n / 12)

  X <- head(tail(X, -endcut), -endcut)
  Y <- head(tail(Y, -endcut), -endcut)

  points(X, Y, type = 'l', ...)

}


#' Table wrappers
#'
#' These functions are simple time saving versions of \code{\link[base]{table}} and \code{\link[base]{prop.table}}.
#' \code{Table} is a wrapper for \code{\link[base]{table}} with \code{useNA = 'ifany'} by default.
#' \code{sTable} is a wrapper for \code{Table} which applies \code{\link[base]{sort}} to the resulting table.
#' \code{pTable} is a wrapper for \code{\link[base]{prop.table}(table)}, with a sorting option.
#' @rdname pstable
#' @export Table sTable pTable
Table <- function(..., useNA = 'ifany') table(..., useNA = useNA)
sTable <- function(..., decreasing = FALSE) sort(Table(...), decreasing = decreasing)
pTable <- function(..., margin = NULL, decreasing = NULL) {
  tab <- Table(...)
  tab <- if(is.null(decreasing)) Table(...) else sTable(..., decreasing = decreasing)

  ptab <- prop.table(tab, margin = margin)

  attr(ptab, 'counts') <- tab
  ptab
}


#####################################################

#' @export
apply2gram_forward  <- fun:x %cf% Map(fun, x, rotate(x, -1))
#' @export
apply2gram_backward <- fun:x %cf% Map(fun, x, rotate(x,  1))


#' @export
roll.apply <- function(x, fun = force, margin = 1, window = 2, step = 1, start = 1, end = 0, simplify = FALSE, ...) {
  isdim <- hasdim(x)
  fun <- match.fun(fun)

  size <- if (margin == 1) if (isdim) nrow(x) else length(x) else ncol(x)

  if (end <= 0 ) end <- size + end

  indices <- lapply(seq(start , end - (window - 1), by = step), seq, length.out = window)

  if (!isdim) {
    sapply(indices, function(i) fun(x[i], ...), simplify = simplify, USE.NAMES = TRUE)
  } else {
    if (margin == 1) {
      sapply(indices, function(i) fun(x[i, , drop = FALSE]), ..., simplify = simplify, USE.NAMES = TRUE)
    } else {
      sapply(indices, function(j) fun(x[, j, drop = FALSE]), ..., simplify = simplify, USE.NAMES = TRUE)
    }
  }
}


#' @export
composeR <- function(func) inherits(func, c('parallel', 'composed', 'partiallyapplied'))


#' @export
argString = function(forms, values = FALSE, defaults = NULL) {
  forms = as.list(forms)
  xs = names(forms)
  if(values) {
    if (is.null(defaults)) stri = forms else stri = forms[mapply(identical, forms, defaults)]
    xs = gsub(' = $', '', paste(xs, sapply(stri, deparse), sep = ' = '))
  }
  paste(xs, collapse = ', ')
}

#' flip a > 1 dimmension object upside down.
#'
#' Like reverse across rows.
#' @export
upsidedown <- function(obj) obj[nrow(obj):1, ]

#' @export
ragged_segments <- func:vec %cf% {
  vec %l|lgl% func -> matches

  if (!identical(func, is.na) && !identical(func, Negate(is.na))) {
    na <- is.na(vec)
    matches[na] <- FALSE
  }
  groupind <- cumsum(matches)

  data.frame(Groups = groupind, Matches = matches, Original = vec)
}

#' @export
fill_forward <- null:obj %cf% {
  if (hasdim(obj)) return(apply(obj, 2, fill_forward(null)))

  func <- if (is.function(null)) null else EQ(null)

  segments <- ragged_segments(Negate(func), obj)

  fills <- obj[segments$Matches]
  if (segments$Groups[1] == 0) {
    fills <- c(NA, fills)
    segments$Groups <- segments$Groups + 1
    }
  fills[segments$Groups]
}

#' @export
fill_backward <- null:obj %cf% {
  obj <- if (hasdim(obj)) upsidedown(obj) else rev(obj)

  obj <- fill_forward(null ,obj)

  if (hasdim(obj)) upsidedown(obj) else rev(obj)
}


#' Find closest match.
#'
#' Find closest valeus in second vector, to each element in first vector.
#'
#' @param direction Character string. Must be either 'either', 'below', 'above', or synonymously for the latter two, 'lessthan', or 'morethan'.
#' However, partial matches are ok, so 'e', 'b', 'a', 'l', or 'm'.
#' @param x The values to be compared
#' @param where The values to be compared against.
#'
#' @usage closest(rnorm(10), -5:5)
#' @export
closest <- function(x, where, direction = 'either', diff_func = `-`) {
  direction <- pmatch(direction, c('either', 'below', 'above', 'lessthan', 'morethan'))


  sortedwhere <- sort(where)
  intervals <- findInterval(x, sortedwhere, )
  hits <- ifelse(intervals == 0,
                 if (direction %in% c(2,4)) Inf else 1,
                 if (direction == 1) {
    intervals + mapply(FUN = function(a,b) which.min(c(a,b)) - 1,
                       abs(x - sortedwhere[intervals]),
                       abs(x - sortedwhere[intervals + 1]))
  } else {
    if (direction %in% c(3, 5))  intervals + 1  else intervals
  })
  sortedwhere[hits]

}

#' @export
contiguous <- function(x) UseMethod('contiguous')
#' @export
contiguous.numeric <- function(x) {
 cumsum(c(TRUE, abs(diff(x)) != 1))
}
#' @export
contiguous.logical <- function(x) {
 cumsum(c(TRUE, diff(x) != 0 ))
}



#' @export
partition <- pred : x %cf% {
 hits <- if (is.function(pred)) pred(x) else pred
 list(Match = x[hits], Not = x[!hits])
}

#' @export
allsame <- function(x) len1(unique(x))
